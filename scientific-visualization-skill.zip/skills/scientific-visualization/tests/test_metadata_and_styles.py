"""Regression tests for DPI metadata quantization and failed style calls."""
from pathlib import Path
import sys
import tempfile
import unittest
from unittest.mock import patch

import matplotlib as mpl
from PIL import Image

SCRIPTS = Path(__file__).resolve().parents[1] / "scripts"
sys.path.insert(0, str(SCRIPTS))
from _common import CliError
from image_metadata import inspect_file, screen_metadata
from style_presets import configure_for_journal
import style_presets


class PngResolutionTests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.root = Path(self.temp.name)

    def tearDown(self):
        self.temp.cleanup()

    def inspect_png(self, dpi, width=100):
        path = self.root / f"image-{dpi}.png"
        pair = dpi if isinstance(dpi, tuple) else (dpi, dpi)
        Image.new("RGB", (width, 80), "white").save(path, dpi=pair)
        return inspect_file(path)

    def test_png_nominal_minimum_survives_integer_phys_quantization(self):
        for dpi in (300, 600):
            with self.subTest(dpi=dpi):
                report = self.inspect_png(dpi)
                self.assertLess(report["metadata"]["dpi_x"], dpi)
                result = screen_metadata(report, min_dpi=dpi)
                self.assertEqual(result["checks"][0]["status"], "pass")

    def test_png_nominal_maximum_survives_integer_phys_quantization(self):
        report = self.inspect_png(72)
        self.assertGreater(report["metadata"]["dpi_x"], 72)
        result = screen_metadata(report, max_dpi=72)
        self.assertEqual(result["checks"][0]["status"], "pass")

    def test_genuinely_low_metadata_dpi_still_fails(self):
        result = screen_metadata(self.inspect_png(299), min_dpi=300)
        self.assertEqual(result["checks"][0]["status"], "fail")

    def test_png_quantization_allowance_is_not_applied_to_tiff(self):
        path = self.root / "image.tiff"
        Image.new("RGB", (100, 80), "white").save(path, dpi=(299.99, 299.99))
        result = screen_metadata(inspect_file(path), min_dpi=300)
        self.assertEqual(result["checks"][0]["status"], "fail")

    def test_effective_dpi_keeps_actual_pixel_threshold(self):
        result = screen_metadata(self.inspect_png(300, width=1051), min_dpi=300, target_width_mm=89)
        self.assertEqual(result["checks"][0]["status"], "fail")
        self.assertAlmostEqual(result["checks"][0]["actual"], 1051 * 25.4 / 89)

    def test_anisotropic_maximum_checks_and_reports_the_higher_axis(self):
        for dpi, axis in (((600, 300), "dpi_x"), ((300, 600), "dpi_y")):
            for bounds in ({"max_dpi": 300}, {"min_dpi": 300, "max_dpi": 300}):
                with self.subTest(dpi=dpi, bounds=bounds):
                    result = screen_metadata(self.inspect_png(dpi), **bounds)
                    check = result["checks"][0]
                    self.assertEqual(check["status"], "fail")
                    self.assertAlmostEqual(check["actual"], 599.9988)
                    self.assertIn(axis, check["detail"])

    def test_anisotropic_minimum_checks_and_reports_the_lower_axis(self):
        for dpi, axis in (((299, 600), "dpi_x"), ((600, 299), "dpi_y")):
            with self.subTest(dpi=dpi):
                result = screen_metadata(self.inspect_png(dpi), min_dpi=300, max_dpi=600)
                check = result["checks"][0]
                self.assertEqual(check["status"], "fail")
                self.assertAlmostEqual(check["actual"], 299.0088)
                self.assertIn(axis, check["detail"])

    def test_anisotropic_axes_allow_only_png_metadata_quantization(self):
        for dpi in ((36, 72), (72, 36)):
            with self.subTest(dpi=dpi):
                check = screen_metadata(self.inspect_png(dpi), min_dpi=36, max_dpi=72)["checks"][0]
                self.assertEqual(check["status"], "pass")

    def test_effective_dpi_does_not_fall_back_to_anisotropic_metadata(self):
        report = self.inspect_png((600, 300), width=1051)
        check = screen_metadata(report, min_dpi=300, target_width_mm=89)["checks"][0]
        self.assertEqual(check["status"], "fail")
        self.assertAlmostEqual(check["actual"], 1051 * 25.4 / 89)
        check = screen_metadata(report, max_dpi=300, target_width_mm=89)["checks"][0]
        self.assertEqual(check["status"], "pass")
        self.assertAlmostEqual(check["actual"], 1051 * 25.4 / 89)

    def test_effective_dpi_boundaries_are_strict_without_quantization(self):
        report = self.inspect_png((600, 300), width=300)
        for bounds in ({"min_dpi": 300.0000000001}, {"max_dpi": 299.9999999999}):
            with self.subTest(bounds=bounds):
                check = screen_metadata(report, target_width_mm=25.4, **bounds)["checks"][0]
                self.assertEqual(check["status"], "fail")
                self.assertEqual(check["actual"], 300.)

    def test_invalid_target_width_is_rejected_at_public_boundary(self):
        report = self.inspect_png(300)
        for value in (0, -1, float("nan"), float("inf"), -float("inf"), "bad"):
            with self.subTest(value=value), self.assertRaises(CliError):
                screen_metadata(report, target_width_mm=value)

    def test_invalid_dpi_thresholds_are_rejected_at_public_boundary(self):
        report = self.inspect_png(300)
        for name in ("min_dpi", "max_dpi"):
            for value in (0, -1, float("nan"), float("inf"), -float("inf"), "bad"):
                with self.subTest(name=name, value=value), self.assertRaises(CliError):
                    screen_metadata(report, **{name: value})

    def test_reversed_dpi_bounds_are_rejected(self):
        with self.assertRaises(CliError):
            screen_metadata(self.inspect_png(300), min_dpi=600, max_dpi=300)


class FailedStyleConfigurationTests(unittest.TestCase):
    def test_configuration_reads_one_profile_snapshot_per_call(self):
        with mpl.rc_context(), patch.object(
            style_presets, "load_publisher_profiles", wraps=style_presets.load_publisher_profiles
        ) as loader:
            result = configure_for_journal("nature")
            self.assertEqual(result["publisher_profile"], "nature")
            self.assertEqual(loader.call_count, 1)

    def test_missing_profile_date_fails_before_any_style_mutation(self):
        document = style_presets.load_publisher_profiles()
        document.pop("accessed", None)
        document["profiles"]["nature"].pop("accessed", None)
        with mpl.rc_context(), patch.object(style_presets, "load_publisher_profiles", return_value=document):
            mpl.rcParams["font.size"] = 13.
            before = dict(mpl.rcParams)
            try:
                configure_for_journal("nature")
            except CliError:
                pass
            except Exception as exc:
                self.fail(f"expected CliError, got {type(exc).__name__}; mutated={dict(mpl.rcParams) != before}")
            else:
                self.fail("missing profile date should be rejected")
            self.assertEqual(dict(mpl.rcParams), before)

    def test_invalid_palette_leaves_rcparams_unchanged(self):
        with mpl.rc_context():
            before = dict(mpl.rcParams)
            with self.assertRaises(CliError):
                configure_for_journal("nature", palette_name="missing-palette")
            self.assertEqual(dict(mpl.rcParams), before)

    def test_invalid_width_or_aspect_leaves_rcparams_unchanged(self):
        for kwargs in ({"figure_width": "not-a-width"}, {"aspect": -1.}, {"aspect": "bad"}):
            with self.subTest(kwargs=kwargs), mpl.rc_context():
                mpl.rcParams["font.size"] = 13.
                mpl.rcParams["figure.figsize"] = (6.2, 4.1)
                before = dict(mpl.rcParams)
                with self.assertRaises(CliError):
                    configure_for_journal("nature", **kwargs)
                self.assertEqual(dict(mpl.rcParams), before)

    def test_invalid_profile_dimensions_leave_rcparams_unchanged(self):
        for width in (0, -1, float("nan"), float("inf"), "bad"):
            document = style_presets.load_publisher_profiles()
            document["profiles"]["nature"]["widths_mm"]["single"] = width
            with self.subTest(width=width), mpl.rc_context(), patch.object(
                style_presets, "load_publisher_profiles", return_value=document
            ):
                before = dict(mpl.rcParams)
                with self.assertRaises(CliError):
                    configure_for_journal("nature")
                self.assertEqual(dict(mpl.rcParams), before)

    def test_valid_configuration_still_applies_style_and_dimensions(self):
        with mpl.rc_context():
            result = configure_for_journal("nature", "single", aspect=.5)
            self.assertEqual(mpl.rcParams["font.size"], 7.)
            self.assertAlmostEqual(mpl.rcParams["figure.figsize"][0], 89 / 25.4)
            self.assertAlmostEqual(mpl.rcParams["figure.figsize"][1], 89 / 25.4 * .5)
            self.assertEqual(result["profile_width"], "single")


if __name__ == "__main__":
    unittest.main()
