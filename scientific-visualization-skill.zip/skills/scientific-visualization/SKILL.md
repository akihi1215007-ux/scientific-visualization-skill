---
name: scientific-visualization
description: Use when 科研任务需要论文数据图、多面板图、方法或架构示意图，或需要检查配色、物理尺寸、字体、图像元数据与导出；不用于重新估计统计量或整篇论文写作。
license: MIT
allowed-tools: Read Write Edit Bash Glob Grep
metadata:
  version: "2.2-portable"
  last-reviewed: "2026-11-03"
  skill-author: K-Dense Inc.
---

# 科研制图

接收已核验的数据或分析结果，完成当前需要的图；不依赖其他技能即可绘图与检查导出。
沿用现有图号、数据版本和项目清单；已有图只修改受影响源文件。样式修改复查导出与可读性；数据/统计定义变化先核验再更新图、图注和引用该结果的文字，单图直接交付。

## 按任务取用

| 当前任务 | 使用什么 |
| --- | --- |
| 数据曲线、分布、热图、多面板 | 默认 Matplotlib；需统计绘图库语法才查 [实现示例](references/matplotlib_examples.md)。交互图才考虑 Plotly |
| 用户指定模板、方法或模型关系图 | [模板与示意图](references/diagram_and_templates.md)：选当前所需素材/格式，共用本次图号与验收 |
| 配色/灰度或色彩编码问题 | [配色参考](references/color_palettes.md)；必要时运行 `palette_audit.py` |
| 改善编码、缺失展示、误差带、图像处理 | [图形原则](references/publication_guidelines.md)，只读相应小节 |
| 检查成品尺寸、像素、DPI、颜色模式或字体 | `image_metadata.py`；它检查文件属性，不能证明科学内容正确 |
| 明确投稿期刊与阶段 | [期刊快照](references/journal_requirements.md) 和 `export_plan.py` 作规划；正式交稿前核对该期刊当前官方要求 |

## 从结果到图

1. 复用现有变量、单位、样本/重复层级、估计值与区间定义。仅补问会改变图形的信息；未指定期刊时按用途给出通用初稿。
2. 选择能回答问题的编码与必要面板。直接比较的图共用单位、标度和颜色含义；面板数量由内容决定。
3. 用局部样式实现，保留可运行源和所用数据。优先展示已核验结果；需要新估计/区间/显著性时交统计环节，得到结果后再画。
4. 按请求导出文件并实际看图：检查最终尺寸下的标签、中文/数学符号、裁切、遮挡、图例、误差带和对比度。只对有疑问的属性运行相应检查工具。
5. 交付源文件、所需成品及必要说明（图号、数据来源、处理、区间/n/单位和未验证项），更新原清单。完整图集、预览拼图、manifest 和多格式导出按需选择。

## 保留科学含义

- 原始数据/图像及处理记录保留；不为美观删点、改值、补造统计量或选择性增强图像。示意图与实测结果明确区分。
- 缺失、零值、删失与排除分开表示；线图保留断点，插值/平滑标明方法。未标定音频不能画成绝对 SPL；声学 dB 写明参考量及幅值/功率约定。
- 误差线说明 SD/SE/CI/分位等定义、n 和独立单位。相关时窗不当作独立重复；绘图时不重新做一轮默认 bootstrap 或检验。
- 柱/面积图通常保留零基线；线/点图可按科学含义取范围。对数轴的零/负值有明确处理，热图标明缺失与色条单位；不靠双轴调范围制造相关。
- 颜色按类别/顺序/有意义中心/周期选用，并结合线型、符号或标签；灰度检查和色板分数只是辅助。网页交付按需提供文字描述、数据替代和非 hover 访问。

## 环境与导出

使用当前项目选定的 Python 3.11+；先检查 Matplotlib、Pillow 和按需使用的 pypdf，不自动修改用户环境。依赖声明见 [requirements.txt](requirements.txt)。无图形界面的环境设置 `MPLBACKEND=Agg`。历史版本与官方来源见 [sources.md](references/sources.md)，不把版本快照当成安装要求。
将本技能目录作为当前目录运行下面的示例；在其他项目中，改为实际技能目录的 `scripts/` 路径。演示数据只用于验证导出，不代表科研结果：

```python
from pathlib import Path
import sys
sys.path.insert(0, str(Path.cwd() / "scripts"))
import matplotlib.pyplot as plt
from style_presets import style_context
from figure_export import export_figure

Path("outputs").mkdir(exist_ok=True)
x, y = [0, 1, 2], [1, 3, 2]  # 导出示例；真实任务换成已核验数据
with style_context("default", palette_name="okabe_ito_on_white"):
    fig, ax = plt.subplots(figsize=(89 / 25.4, 60 / 25.4), layout="constrained")
    ax.plot(x, y, marker="o")  # x/y 来自本次结果；缺失保留为 NaN
    ax.set(xlabel="Frequency (Hz)", ylabel="Response (unit)")
    report = export_figure(fig, "outputs/figure1", formats=["pdf", "png"], dpi=600)
plt.close(fig)
```

- 使用 `style_context` 避免全局样式泄漏；精确物理尺寸用 `bbox_inches=None`，不随后调用 `tight_layout()`。导出前建立所需目录。
- PDF/SVG 保留矢量文字/线条；DPI 仍影响内嵌栅格。PDF Type 42 嵌入 TrueType；SVG 文字可编辑但依赖接收端字体，转路径会失去文字编辑能力。
- TIFF 需 RGB 无 alpha 时显式 `tiff_rgb=True`；EPS/PS 不能保留半透明，存在误差带/透明图层时优先 PDF/SVG，指定 EPS 时检查不透明后的效果。
- 标称 DPI 与最终尺寸下的有效 DPI 分别判断；像素不足不能靠修改 DPI 标签或放大来补细节。PNG 标称 DPI 允许文件格式自身的微小量化误差。
- 导出默认拒绝覆盖，单文件原子写入；多格式整批不是事务。`--force`/`overwrite=True` 仅用于明确替换目标。保留现有脚本和公开接口。
- 工具入口：`figure_export.py --help`、`image_metadata.py --help`、`palette_audit.py --help`、`export_plan.py --help`、`style_presets.py --help`；`style_preview.py` 仅在需要样式预览时运行。

## 衔接

若已安装，可将新统计问题交给 `statistical-analysis`，正文、图注和表格内容交给 `research-writing-skill`；它们不是运行依赖。未安装时说明所缺分析或写作工作，保留已完成图，不假定本机存在其他技能。本环核对图注与图中编码相符，传递同一版数字，不另起论文写作或 Word 排版流程。

来源及再分发说明见 [THIRD_PARTY_NOTICES.md](THIRD_PARTY_NOTICES.md)，许可见 [LICENSE](LICENSE)。
