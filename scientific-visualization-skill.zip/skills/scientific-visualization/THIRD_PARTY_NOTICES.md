# 来源与第三方说明

## 科研制图技能及本次适配

本技能基于 K-Dense Inc. 的 scientific-visualization 技能及其后续本地修订版本，保留源文件中的 `skill-author: K-Dense Inc.`、配色来源和出版商来源说明。K-Dense 上游：[scientific-agent-skills](https://github.com/K-Dense-AI/scientific-agent-skills)，已核对的[原技能入口](https://github.com/K-Dense-AI/scientific-agent-skills/blob/a1043ef544e3a100c28e70a736b6cf32554d0677/skills/scientific-visualization/SKILL.md)。本包不是 K-Dense 官方发布，也不表示原作者为后续修订背书。

上游 MIT 许可正文完整保存在同目录 [LICENSE](LICENSE)，保留 `Copyright (c) 2025 K-Dense Inc.`。本次核对的[上游许可证](https://raw.githubusercontent.com/K-Dense-AI/scientific-agent-skills/a1043ef544e3a100c28e70a736b6cf32554d0677/LICENSE.md)对应提交 `a1043ef544e3a100c28e70a736b6cf32554d0677`；该提交只标识许可证核对来源，不代表本地 20 个源文件均逐字来自该提交。无法从现有来源确定每项历史修订的完整提交谱系，因此不虚构更精确的代码归属。

初次可移植适配移除个人解释器和同伴技能的绝对路径，改写可选模板指引，补充依赖、安装和验证文档；保留原 7 个脚本、5 个资源文件及 12 项测试。2026-11-03另修复元数据参数校验和期刊样式配置复用，扩展至19项测试，公开接口保持。新增的简单三节点 SVG 示例独立编写，不复制外部图形素材。本仓库新增的包装文档与该示例亦按 MIT 许可提供。

## 随包资源

- `assets/color_palettes.py` 含 Okabe–Ito/Wong、Paul Tol 的公开 sRGB 配色数值及来源链接；保留这些归属。参考 [Wong, Nature Methods (2011)](https://www.nature.com/articles/nmeth.1618) 和 [Paul Tol Colour Schemes](https://sronpersonalpages.nl/~pault/data/colourschemes.pdf)。本包不包含这些文章、PDF 或作者的完整软件实现；对配色数值的引述不表示拥有原文权利。
- `assets/*.mplstyle` 是绘图参数配置，不是字体文件。`assets/publisher_profiles.json` 是带日期的出版商要求摘要；不表示出版商授权、背书或当前合规认证。官方来源保留在 [references/sources.md](references/sources.md)。
- 依赖通过包管理器单独安装，不捆绑 Matplotlib、NumPy、Pillow 或 pypdf 的源码/二进制；它们遵循各自许可证。调用库内色图不等于重新发布色图实现。
- 本包无第三方字体、照片、论文图像、Vivid 模板/脚本/索引或其他素材库。

## 仅链接的可选项目

[Vivid](https://github.com/yjz211/vivid-illustration-skill) 的已核对来源采用个人非商业许可，并限制修改和再分发。本包仅链接来源及提示许可边界，不将其内容作为 MIT 附件。具体使用以取得素材时的许可及书面授权为准。

[draw.io 官方项目](https://github.com/jgraph/drawio)与 [drawio-skill](https://github.com/Agents365-ai/drawio-skill)仅作为可选外部工具链接，不是本包组成部分。用户应分别核对其版本、依赖和许可。

其他网页均为引文或技术参考；网页、商标和出版社要求不因被引用而改用本仓库许可证。
