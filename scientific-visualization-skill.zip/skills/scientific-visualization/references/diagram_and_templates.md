# 模板与科研示意图

本技能的核心绘图、导出和检查不依赖 Vivid、draw.io 或任何其他技能。先确定图表达的是量值还是关系，以及用户需要的可编辑格式；不用为普通数据图安装模板库。

## 独立完成简单示意图

1. 从用户材料列出节点、分组、箭头方向及各条连接的含义；未知关系先标为待确认。
2. 少量节点用自己的 SVG 元素或 Matplotlib `patches` / `annotate` 布局；保持文字、形状和连线可编辑，不把参考图片作为底图冒充重建。
3. 保存源文件；根据请求导出 SVG/PDF/PNG，并在最终尺寸下检查文字、连接点、裁切和重叠。
4. 把概念关系图标明为“示意”，不添造实测曲线、系数、显著性或模型结构。

下面是独立的三节点 SVG 最小起点，可保存为 `workflow.svg` 后用浏览器检查。替换节点及箭头含义，不把示例顺序当成项目事实：

```svg
<svg xmlns="http://www.w3.org/2000/svg" width="720" height="180" viewBox="0 0 720 180" role="img" aria-labelledby="title desc">
  <title id="title">Illustrative workflow</title>
  <desc id="desc">Input connects to analysis, then to output. Conceptual example only.</desc>
  <defs>
    <marker id="arrow" markerWidth="8" markerHeight="8" refX="7" refY="4" orient="auto">
      <path d="M0,0 L8,4 L0,8 Z" fill="#334155"/>
    </marker>
  </defs>
  <g fill="#f1f5f9" stroke="#334155" stroke-width="2">
    <rect x="30" y="55" width="170" height="70" rx="8"/>
    <rect x="275" y="55" width="170" height="70" rx="8"/>
    <rect x="520" y="55" width="170" height="70" rx="8"/>
  </g>
  <g fill="none" stroke="#334155" stroke-width="2" marker-end="url(#arrow)">
    <path d="M200,90 H265"/><path d="M445,90 H510"/>
  </g>
  <g font-family="sans-serif" font-size="22" text-anchor="middle" fill="#0f172a">
    <text x="115" y="98">Input</text><text x="360" y="98">Analysis</text><text x="605" y="98">Output</text>
  </g>
</svg>
```

SVG 中的文字依赖接收端字体；中文和公式需在实际环境复核。另存文字转路径版本时保留原始可编辑文本文件。

## 可选外部扩展（不随包安装）

- **Vivid**：[公开上游仓库](https://github.com/yjz211/vivid-illustration-skill)。仅当用户明确需要该来源时，先阅读上游当前 `LICENSE` 和具体素材声明。本次打包时核对的本地来源声明为个人非商业许可，并限制修改、衍生和再分发；不能视作 MIT 素材，也不能据此默认提取、改编或打包模板。需要的用途未获授权时使用上面的独立实现。本包不附带 Vivid 的代码、模板、字体、图片、索引或导出器，不宣称测试过该扩展。
- **draw.io / diagrams.net**：[官方项目](https://github.com/jgraph/drawio)提供原生 `.drawio` 格式；可选的 [drawio-skill 上游](https://github.com/Agents365-ai/drawio-skill)是独立社区项目。只有用户要求此格式且工具已可用时才采用，并分别核对许可和依赖。该扩展未包含在本包中。
- **原生 PPTX**：本包没有 PPTX 转换器。需要形状和文本可编辑时使用用户可用的演示文稿工具，并检查实际 shape/text；把 SVG/PNG 作为图片插入不是原生图形。不能在没有 Office 实际渲染的情况下声称通过 Office 视觉验收。
- **论文表格**：直接使用用户提供的已核验数字、明确单位、列名、有效位数和缺失标记。优先交付当前需要的 Markdown/LaTeX 表格源码；无需任何本地表格素材库。文献能力矩阵的每个判断须有来源，未知记为未知。

## 使用已获授权的外部素材

记录公开来源 URL、取得日期、明确许可与修改范围；单个字体/图标可能有独立条款。替换所有演示数据、统计量、标签和单位。SHAP 图需要真实对应的特征与 SHAP 值，SEM 图需要实际模型与估计；固定种子不证明科学分析正确。

## 共同验收

分别检查数据值/单位、图形编码、箭头关系、中文与公式、字体、裁切/重叠、可编辑源和实际导出。只交付用户需要的图数和格式。图形摘要和概念插图明确示意属性；涉及实测曲线、显微图像、谱图或数值结果时必须使用对应真实来源。
